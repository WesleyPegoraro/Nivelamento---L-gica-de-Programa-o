def add1(a):
    b=a+1
    return b

add1(5)
c = add1(10)