n = int(input("Digite um número:"))

mult = 1
i = 1

while i <= 10:
    mult = i * n
    print(f"{n} X {i} = {mult}")
    i = i + 1