# Função que calcula a média de 2 números
def media2n(n1, n2):
    return (n1 + n2) / 2