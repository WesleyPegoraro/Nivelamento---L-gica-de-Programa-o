# Procedimento para exibir a média semestral
def msg_media_semestral(m):
    print(f"A sua Média Semestral é {m:.1f}")

# Cálculo da media semestral com as duas notas maiores
#    media_semestral = (nota1 + nota2 + nota3 - menor_nota) / 2
#    print(f"A sua Média Semestral é {media_semestral:.1f}")