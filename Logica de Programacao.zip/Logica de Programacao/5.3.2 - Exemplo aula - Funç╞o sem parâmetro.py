# Criação da função sem parâmetro
def pi():
    return 3.1415

# Chamada da função
print("PI = ", pi())