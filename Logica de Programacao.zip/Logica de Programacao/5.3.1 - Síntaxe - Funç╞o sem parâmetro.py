# def <nome da função>():
#    corpo da função
#    return(<valor>)