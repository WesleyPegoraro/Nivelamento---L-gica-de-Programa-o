num = int(input("Digite um número"))
# início da contagem das voltas em 1
volta = 1

while volta <= 10:
    mult = num * volta
    print(num)
    volta = volta + 1