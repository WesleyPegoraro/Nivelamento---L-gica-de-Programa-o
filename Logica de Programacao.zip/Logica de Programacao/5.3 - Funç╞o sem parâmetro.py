# Função sem parâmetro
def pi():
    return 3.14159


# Programa principal
r = 15
a = pi() * r ** 2
print("A área do círculo com raio ", r, " é", a)