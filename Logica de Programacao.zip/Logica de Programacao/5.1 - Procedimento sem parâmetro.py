# Subalgoritmos - Criação do procedimento
def saudacao():
    print("Olá Usuário, você está logado")

# Programa principal - Chamada do procedimento
saudacao()