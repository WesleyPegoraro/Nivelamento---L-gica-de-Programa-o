num = int(input("Digite um número: "))

for i in range(1,11,1):
    mult = num * i
    print(mult)