# def <nome da função>([<parâmetros>]):
#    corpo da função
#    return <valor>